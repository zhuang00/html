CREATE VIEW news_views AS
  SELECT
    `c1`.`news`.`title` AS `title`,
    `c1`.`news`.`nid`   AS `nid`
  FROM `c1`.`news`;
