CREATE VIEW news_category_view AS
  SELECT
    `n`.`cid`   AS `cid`,
    `n`.`nid`   AS `nid`,
    `n`.`title` AS `title`,
    `c`.`cname` AS `cname`
  FROM (`c1`.`news` `n`
    JOIN `c1`.`category` `c` ON ((`n`.`cid` = `c`.`cid`)));
