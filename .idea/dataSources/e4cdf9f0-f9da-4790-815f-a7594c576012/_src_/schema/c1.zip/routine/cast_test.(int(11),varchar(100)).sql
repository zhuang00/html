CREATE PROCEDURE cast_test(IN n INT, INOUT str VARCHAR(100))
  begin
case n
when 1 then
set str='is one';
when 2 then
set str='is two';
else
set str='i do not know';
end case;
end;
