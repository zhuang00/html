CREATE PROCEDURE add_user_prefix(IN `_uid` INT, IN `_pre` VARCHAR(100))
  begin
if isnull(_uid) then
update user set uname=concat(_pre,uname);
else
update user set uname=concat(_pre,uname) where uid=_uid;
end if;
end;
