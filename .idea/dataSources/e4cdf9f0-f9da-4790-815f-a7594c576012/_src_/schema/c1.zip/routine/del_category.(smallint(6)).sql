CREATE PROCEDURE del_category(IN cat_id SMALLINT(6))
  begin
    delete from category where cid=cat_id;
    delete from news where cid=cat_id;
end;
