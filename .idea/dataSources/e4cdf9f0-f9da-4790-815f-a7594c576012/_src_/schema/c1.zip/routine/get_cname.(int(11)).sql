CREATE FUNCTION get_cname(`_nid` INT)
  RETURNS VARCHAR(100)
  begin
    if isnull(_nid) then
    return null;
    else
        return (select cname from category where cid in(select cid from news where nid=_nid));
    end if;
end;
