CREATE PROCEDURE hd()
  begin
    declare n int default 2000;
    while n>0 do
        insert into news set title=concat("这是第",n,"篇文章"),cid=3;
        set n=n-1;
    end while;
end;
