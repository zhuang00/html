CREATE PROCEDURE c()
  begin
    select * from user;
end;
