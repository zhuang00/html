CREATE PROCEDURE test(IN n INT)
  begin
if n>100 then
select "大于100";
elseif n>50 then
select "大于50";
end if;
end;
