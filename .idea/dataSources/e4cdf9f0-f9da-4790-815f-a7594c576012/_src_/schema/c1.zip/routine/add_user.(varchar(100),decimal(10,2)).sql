CREATE PROCEDURE add_user(IN `_uname` VARCHAR(100), IN `_money` DECIMAL(10, 2))
  begin
   insert into user set uname=_uname,money=_money;
end;
