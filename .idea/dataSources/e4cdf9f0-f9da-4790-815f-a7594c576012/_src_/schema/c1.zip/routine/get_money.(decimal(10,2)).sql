CREATE FUNCTION get_money(`_money` DECIMAL(10, 2))
  RETURNS VARCHAR(100)
  begin
    if _money>1000 then
    return '高收入';
    else
    return '低收入';
    end if;
end;
