CREATE FUNCTION hd_concat(`_uname` VARCHAR(100))
  RETURNS VARCHAR(100)
  begin
return concat('后盾_',_uname);
end;
