CREATE TRIGGER UpdateNews
BEFORE UPDATE ON news
FOR EACH ROW
  begin
    set new.update_time=now();
end;
