CREATE TRIGGER InsertNews
BEFORE INSERT ON news
FOR EACH ROW
  begin
    if new.source='' then
        set new.source='后盾网';
    end if;
    if new.update_time is null then
        set new.update_time=now();
    end if;
end;
