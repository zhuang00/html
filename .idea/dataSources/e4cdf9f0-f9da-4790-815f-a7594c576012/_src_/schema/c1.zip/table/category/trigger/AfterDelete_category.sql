CREATE TRIGGER AfterDelete_category
AFTER DELETE ON category
FOR EACH ROW
  begin
    delete from news where cid=old.cid;
end;
